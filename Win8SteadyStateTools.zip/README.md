# Win8SteadyStateTools
Updating tools for a Windows 8 (and beyond) Steady State Config. These are built on Panos Macheras' Win7 Steady State Solution found here: http://blogs.technet.com/b/panosm/archive/2011/07/07/windows-7-steadystate-solution-simplified.aspx

The above blog was a great jumping off point for a SteadyState config but we needed one for our laptops and domain connected devices so I'm going to dump much of the work we've done to this repo.

Extract these tools to the $oem$\$$\system dir of your MDT Deployment Share. If you don't have this directory, copy them to any location you'd like to clal them from during the build, or look into Michael Niehaus' CopyOEM MDT script here: http://blogs.technet.com/b/mniehaus/archive/2012/08/24/copying-oem-files-and-folders-with-mdt-2012-update-1.aspx



